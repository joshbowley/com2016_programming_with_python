# hello world function
def printHelloWorld ():
    print("Hello, World!")

# call the function
printHelloWorld()
