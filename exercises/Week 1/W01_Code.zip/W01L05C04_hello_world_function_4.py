
# hello world function
def print_hello_world(i_text_1, i_text_2):
    text_2 = "Hello!"
    my_text = i_text_1+i_text_2
    print (my_text)
    
    i_text_2 = " Hello!"
    my_text = i_text_1+i_text_2
    print(my_text)

# call the function
text_1 = "Hello, "
text_2 = " World! "
print_hello_world(text_1,text_2)
my_text = text_1+text_2
print (my_text)
