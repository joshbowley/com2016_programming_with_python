# hello world function
def print_hello_world(i_text_1, i_text_2):
    my_text = i_text_1+i_text_2
    print(my_text)

# another function
def another_function():
    print("This is another function.")
    
    

