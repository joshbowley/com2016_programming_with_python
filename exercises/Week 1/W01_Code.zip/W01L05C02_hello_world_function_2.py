# hello world function
def print_hello_world():
    text_1 = "Hello, "
    text_2 = " World! "
    my_text = text_1+text_2
    print(my_text )

# call the function
text = "Hello!"
print_hello_world()
