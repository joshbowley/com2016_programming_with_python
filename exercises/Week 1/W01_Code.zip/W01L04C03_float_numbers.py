
# Declare and initialise variables 
price_cheese = 3.45
price_bread = 2.21

# Print prices of cheese and bread
print("Cheese:", price_cheese)
print("Bread:", price_bread)
