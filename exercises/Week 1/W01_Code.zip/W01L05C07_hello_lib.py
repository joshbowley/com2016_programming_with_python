
import hello_lib

# definition of variables
text_1 = "Hello, "
text_2 = "World! "
# call the function
hello_lib.print_hello_world(text_1,text_2)

