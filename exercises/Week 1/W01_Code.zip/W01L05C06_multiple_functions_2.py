# This function prints a greeting message
def greet(name):          
    print("Hello", name)  
    
# This function calls another function
def welcome_user(name):   
    print("Welcome message:")  
    greet(name)           

# Function call with an argument
welcome_user("Alice")     


"""

    
*** AI Declaration ***

Prompt: now give me an example of a function calling another function

def greet(name):
    print("Hello", name)

def welcome_user(name):
    print("Welcome message:")
    greet(name)   # calling another function

welcome_user("Alice")

"""