
# Declare and initialize a variable named age_John
age_John = 25

# Declare and initialize a variable named age_Ann
age_Ann = 26

# Print John's age
print("John:", age_John)

# Print Ann's age
print("Ann:", age_Ann)
