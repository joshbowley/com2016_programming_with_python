
# Declare and initialise variables 
person_name = "John"
person_age = 25

item_name = "Cheese"
item_prince = 3.45

# Modifying variables
person_age = person_age + 1 
item_prince = 4.5  

# Print prices of cheese and bread
print(person_name, person_age)
print(item_name, item_prince)
