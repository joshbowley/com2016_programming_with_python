# Define a variable with the string "Hello World"
message = "Hello World!"

message_type = type(message)
print(message_type)  # This will print: <class 'str'>


# This statement prints “Hello World”
print("Hello World!")
# This statement also prints “Hello World”
print(message)
