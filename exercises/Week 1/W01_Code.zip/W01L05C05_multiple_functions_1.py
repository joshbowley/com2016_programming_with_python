
# Function to greet a person
def greet(name):  
    print("Hello", name)

# Function to say farewell to a person
def farewell(name):
    print("Goodbye", name)

# calls the greet function
greet("Alice")      
# calls the farewell function
farewell("Alice")   



""" 
*** AI Declaration ***

Prompt: 
We have one function greet(), create another relevant small function

ChatGPT:
def farewell(name):  # 'name' is a parameter
    print("Goodbye", name)

greet("Alice")      # calls the greet function
farewell("Alice")   # calls the farewell function


"""