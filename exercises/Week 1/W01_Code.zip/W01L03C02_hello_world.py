# This statement prints “Hello World”
print("Hello World!")


""" 
This statement prints 
“Hello World”
"""
print("Hello World!")
